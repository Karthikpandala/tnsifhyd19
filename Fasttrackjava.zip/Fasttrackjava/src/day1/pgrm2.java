package day1;

public class pgrm2 {

	public static void main(String[] args) {
	

	}

}
