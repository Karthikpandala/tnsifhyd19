package day1;

public class Program20 {
	public static void main(String[] args)
	 {
	 
  int[] array = {3, 11, 16, 8, 5}; 
   int sum = 0; for (int num : array) { sum += num; 
	} 
	System.out.println("Sum of elements in the array: " + sum); 
	    } 
	}

