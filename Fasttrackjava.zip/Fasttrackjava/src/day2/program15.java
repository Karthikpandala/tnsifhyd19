package day2;

public class program15 {

	public static void main(String[] args) {
		int x=10;
		System.out.println(--x);
	}

}
