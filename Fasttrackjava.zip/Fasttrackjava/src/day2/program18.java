package day2;

public class program18 {

	public static void main(String[] args) {
		int x;
		x=(10==9)?1:0;
		System.out.println(x);
	}

}
