package day2;

import java.util.Scanner;
public class pgrm2 {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the integer :");
		int data1=input.nextInt();
		System.out.println("using nextLine():"+data1);
		input.close();
		}
}
