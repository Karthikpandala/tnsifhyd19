package day2;

public class program11 {

	public static void main(String[] args) {
		int mod=13%2;
		System.out.println(mod);

	}

}
