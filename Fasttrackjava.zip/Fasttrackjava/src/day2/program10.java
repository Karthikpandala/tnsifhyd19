package day2;

public class program10 {

	public static void main(String[] args) {
		
		int x=1;
		int y=12/2;
		System.out.println(y);
	}

}
