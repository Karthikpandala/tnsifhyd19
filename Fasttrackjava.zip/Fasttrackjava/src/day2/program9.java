package day2;

public class program9 {

	public static void main(String[] args) {
	
		int x=1;
		int y=12*2;
		System.out.println(y);
		}
}
