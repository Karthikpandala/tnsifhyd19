package day2;

import java.util.Scanner;

public class pgrm3 {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter double value :");
		double value=input.nextDouble();
		System.out.println("using nextDouble:"+value);
		input.close();
	}
}
