package day2;

public class program8 {

	public static void main(String[] args) {
		int x=1;
		int y=12-x;
		System.out.println(y);
	}

}
