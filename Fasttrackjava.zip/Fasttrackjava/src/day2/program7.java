package day2;

public class program7 {

	public static void main(String[] args) {

		int x=1+2;
		String s="Hello"+"world";
		System.out.println(x);
		System.out.println(s);

	}

}
