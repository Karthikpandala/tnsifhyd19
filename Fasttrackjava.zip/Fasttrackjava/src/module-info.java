/**
 * 
 */
/**
 * 
 */
module Fasttrackjava {
}