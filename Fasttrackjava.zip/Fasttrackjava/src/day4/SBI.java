package day4;

public class SBI implements Bank {
	public float rateOfInterest()
	{
	return 9.15f;
	}
}
