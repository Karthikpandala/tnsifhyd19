package day4;

abstract class program1 {
	abstract void fun();

}
