package day4;

public class program1main {
	public static void main(String args[])
	{
	program1 b = new program1derived();
	b.fun();
	}


}
