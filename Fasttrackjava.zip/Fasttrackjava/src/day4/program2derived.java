package day4;

public class program2derived extends program2base{
	program2derived(){
		System.out.println("Derived Constructor Called");
		}
	void fun()
	{
	System.out.println("Derived fun() called");
	}
	}
