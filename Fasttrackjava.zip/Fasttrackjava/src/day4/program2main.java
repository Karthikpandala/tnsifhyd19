package day4;

public class program2main {

	public static void main(String args[])
	{
		program2derived d = new program2derived();
	}

}

