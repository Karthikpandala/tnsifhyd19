package day4;

public class ICICI implements Bank {
	public float rateOfInterest()
	{
	return 9.7f;
	}

}
