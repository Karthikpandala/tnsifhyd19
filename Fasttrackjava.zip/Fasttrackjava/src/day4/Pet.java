package day4;

public interface Pet {
	public void test();

}
