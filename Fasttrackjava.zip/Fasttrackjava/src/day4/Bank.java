package day4;

public interface Bank {
	float rateOfInterest();
	}

