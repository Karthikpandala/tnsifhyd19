package day4;

	abstract class program2base
	{
		program2base()
		{
		System.out.println("Base Constructor Called");
		}
		abstract void fun();

	}
