package day4;

public class program1derived extends program1 {
	void fun()
	{
	System.out.println("Derived fun() called");
	}

}
